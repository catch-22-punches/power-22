#!bin/bash
sudo apt install cowsay
