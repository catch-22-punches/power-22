# Ansible playbooks for Palo Alto Networks firewalls
## Needs work
- [ ]: [pa-setup.sh](pa-setup.sh) Needs to be better
- [ ]: [palo-init.yaml](pa-setup.sh) Needs to become more robust