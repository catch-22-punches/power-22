# Count off!

echo "`whoami`:$HOSTNAME"
