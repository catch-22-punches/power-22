# User security.

# hidden users with shells
# uid 0 users

# manual for now :z
